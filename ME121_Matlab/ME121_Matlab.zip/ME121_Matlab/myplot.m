function myplot(xmax)

x = linspace(0,xmax);
y = sin(x);
plot(x,y,'o')
